package com.elementzinteractive.personalinfo.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.elementzinteractive.personalinfo.API.UserInterface;
import com.elementzinteractive.personalinfo.R;
import com.elementzinteractive.personalinfo.Singleton.CurrentUser;
import com.elementzinteractive.personalinfo.activity.MainActivity;
import com.elementzinteractive.personalinfo.adapter.PersonAdapter;
import com.elementzinteractive.personalinfo.model.JsonObj;
import com.elementzinteractive.personalinfo.model.Person;
import com.elementzinteractive.personalinfo.model.Result;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link PersonListFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link PersonListFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PersonListFragment extends Fragment {

    //region VARIABLES
    String API = "http://api.randomuser.me";
    ProgressBar progressBar;
    PersonAdapter adapter;
    ListView listView;
    List<Person> listPersons;
    List<Person> listAllPersons;
    RestAdapter restAdapter;
    boolean isScrollDown = false;
    int start = 0;
    int end = 0;

    //endregion

    //region CONSTRUCTOR
    public PersonListFragment() {
        // Required empty public constructor
    }
    //endregion

    //region INSTANCE
    public static PersonListFragment newInstance(Bundle bundle) {
        PersonListFragment personListFragment = new PersonListFragment();
        personListFragment.setArguments(bundle);
        return personListFragment;
    }
    //endregion

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_person_list, container, false);
        progressBar = (ProgressBar) getActivity().findViewById(R.id.toolbar_progress_bar);
        progressBar.setVisibility(View.VISIBLE);
        // Inflate the layout for this fragment
        listView = (ListView) view.findViewById(R.id.lvwPersons);
        listPersons = new ArrayList<Person>();
        listAllPersons = new ArrayList<Person>();
        adapter = new PersonAdapter(getContext(), listPersons);
        listView.setAdapter(adapter);

        restAdapter = new RestAdapter.Builder().setEndpoint(API).build();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> av, View view, int i, long l) {

                String name = ((TextView) view.findViewById(R.id.tvName)).getText().toString();
                String lastname = ((TextView) view.findViewById(R.id.tvLastName)).getText().toString();
                String firstname = ((TextView) view.findViewById(R.id.tvFirstName)).getText().toString();
                String gender = ((TextView) view.findViewById(R.id.tvGender)).getText().toString();
                String birthdate = ((TextView) view.findViewById(R.id.tvBirthDate)).getText().toString();
                String number = ((TextView) view.findViewById(R.id.tvPhone)).getText().toString();
                String email = ((TextView) view.findViewById(R.id.tvEmail)).getText().toString();
                String url = ((TextView) view.findViewById(R.id.tvImageURL)).getText().toString();

                CurrentUser.getInstance().setPerson(new Person(url, lastname, firstname, gender, birthdate, number, email));
                //((MainActivity) getActivity()).setBundle(bundle);
                ((MainActivity) getActivity()).setCurrentPagerItem(1);
            }
        });
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }

            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {
                if (firstVisibleItem + visibleItemCount == totalItemCount && totalItemCount != 0) {
                    if (!isScrollDown) {
                        LoadMoreUsers();
                    }
                } else
                    isScrollDown = false;
            }
        });
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        initialLoadUser();
    }

    public void initialLoadUser() {
        start = 0;
        UserInterface userInterface = restAdapter.create(UserInterface.class);
        userInterface.getUsers(getResources().getString(R.string.initial_list_count), new Callback<JsonObj>() {
            @Override
            public void success(JsonObj model, Response response) {
                for (Result result : model.getResults()) {
                    String dateAsText = new SimpleDateFormat(getResources().getString(R.string.birthdate_format))
                            .format(new Date(result.getUser().getDob() * 1000L));

                    listAllPersons.add(new Person(result.getUser().getPicture().getMedium(),
                            result.getUser().getName().getLast(),
                            result.getUser().getName().getFirst(),
                            result.getUser().getGender(),
                            dateAsText,
                            result.getUser().getPhone(),
                            result.getUser().getEmail()));

                    if (start < 7)
                        start++;
                    else continue;

                    listPersons.add(new Person(result.getUser().getPicture().getMedium(),
                            result.getUser().getName().getLast(),
                            result.getUser().getName().getFirst(),
                            result.getUser().getGender(),
                            dateAsText,
                            result.getUser().getPhone(),
                            result.getUser().getEmail()));

                    adapter.notifyDataSetChanged();
                }
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void failure(RetrofitError error) {
                String merror = error.getMessage();
            }
        });
    }

    public void LoadMoreUsers() {
        if (start == listAllPersons.size()) return;
        listPersons.addAll(listAllPersons.subList(start, start + 1));
        adapter.notifyDataSetChanged();
        start += 1;
        isScrollDown = true;
        //region OLD CODE
       /* UserInterface userInterface = restAdapter.create(UserInterface.class);
        userInterface.getUsers(getResources().getString(R.string.load_more_count), new Callback<JsonObj>() {
            @Override
            public void success(JsonObj model, Response response) {
                for (Result result : model.getResults()) {
                    String dateAsText = new SimpleDateFormat(getResources().getString(R.string.birthdate_format))
                            .format(new Date(result.getUser().getDob() * 1000L));

                    listPersons.add(new Person(result.getUser().getPicture().getMedium(),
                            result.getUser().getName().getLast(),
                            result.getUser().getName().getFirst(),
                            result.getUser().getGender(),
                            dateAsText,
                            result.getUser().getPhone(),
                            result.getUser().getEmail()));
                }
               // listView.removeFooterView(footerView);
                adapter.notifyDataSetChanged();
                isScrollDown = true;
            }
            @Override
            public void failure(RetrofitError error) {
                String merror = error.getMessage();
            }
        });*/
        //endregion
    }

}
