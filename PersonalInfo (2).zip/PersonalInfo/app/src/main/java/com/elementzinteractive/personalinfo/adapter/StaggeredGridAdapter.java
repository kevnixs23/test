package com.elementzinteractive.personalinfo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.elementzinteractive.personalinfo.R;
import com.elementzinteractive.personalinfo.model.Person;
import com.etsy.android.grid.util.DynamicHeightImageView;
import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.Vector;

/**
 * Created by Elementz on 2/15/2016.
 */
public class StaggeredGridAdapter extends BaseAdapter {
    private Context mContext;
    private List<Person> mListContact;
    private List<View> mListView;

    public StaggeredGridAdapter(Context context, List<Person> list) {
        mContext = context;
        mListContact = list;
        mListView = new Vector<View>();
    }

    @Override
    public int getCount() {
        return mListContact.size();
    }

    @Override
    public Object getItem(int pos) {
        return mListContact.get(pos);
    }

    @Override
    public long getItemId(int pos) {
        return pos;
    }

    @Override
    public View getView(int pos, View convertView, ViewGroup parent) {

        // get selected entry
        Person entry = mListContact.get(pos);
        // inflating list view layout if null
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            convertView = inflater.inflate(R.layout.person_list_view, null);
        }
        DynamicHeightImageView imgView = (DynamicHeightImageView)convertView.findViewById(R.id.dyImgView);
        Picasso.with(convertView.getContext())
                .load(entry.getAvatarURL())
                .placeholder(R.drawable.user) // optional
                .error(R.drawable.circle)// optional
                .into(imgView);
        // set name
        TextView tvName = (TextView) convertView.findViewById(R.id.tvNameGridView);
        tvName.setText(entry.getFirstName() + " " + entry.getLastName());

        mListView.add(convertView);
        return convertView;
    }

    public List<View> getViewList()
    {
        return mListView;
    }


}
